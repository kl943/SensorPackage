package cece.sensorpackage;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class Text extends Activity implements OnClickListener{

	private Button startBtn;
	private Button stopBtn;
	
	private RecordingThread recordingThread;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.text);
		
		startBtn = (Button) findViewById(R.id.start_btn);
		startBtn.setOnClickListener(this);

		stopBtn = (Button) findViewById(R.id.stop_btn);
		stopBtn.setOnClickListener(this);
		
		
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		
		switch (v.getId()) {
		case R.id.start_btn:
			
			startBtn.setVisibility(View.INVISIBLE);
			stopBtn.setVisibility(View.VISIBLE);

			recordingThread = new RecordingThread();
			recordingThread.start();
			
			break;

		case R.id.stop_btn:
			
			startBtn.setVisibility(View.VISIBLE);
			stopBtn.setVisibility(View.INVISIBLE);
			
			recordingThread.stopRecording();
			
			break;
		}
		
	}

	

}
